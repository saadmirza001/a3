from django.db import models
from django.utils import timezone

class Ticket(models.Model):
    timestamp = models.DateTimeField(default=timezone.now)  
    location = models.CharField(max_length=100)

    def __str__(self):
        return f'Ticket at {self.timestamp.strftime("%A, %m-%d-%Y %H:%M")} - {self.location}'