from django.shortcuts import render, redirect
from django.utils import timezone
from .models import Ticket
from datetime import datetime  # Import the datetime module

def tick(request):
    if request.method == 'POST':
        timestamp_str = request.POST.get('timestamp')
        location = request.POST.get('location')
        timestamp = timezone.now() if not timestamp_str else timezone.make_aware(datetime.fromisoformat(timestamp_str))

        Ticket.objects.create(timestamp=timestamp, location=location)
        return redirect('log')

    return render(request, 'park.html')

def log(request):
    tickets = Ticket.objects.all()
    return render(request, 'logs.html', {'tickets': tickets})